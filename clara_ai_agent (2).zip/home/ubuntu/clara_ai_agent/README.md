# Clara AI Sales Agent - MVP

**Clara AI** is an intelligent voice-based sales qualification system that automates the initial lead qualification process for real estate agents. It uses OpenAI's GPT-4o to conduct natural, human-like conversations with leads via Twilio phone calls.

## Features

- **Automated Lead Qualification:** Conducts a 5-question qualification script with leads.
- **Natural Conversation:** Uses GPT-4o to generate human-like responses.
- **Voice Integration:** Integrates with Twilio for voice calls and SMS.
- **Lead Management:** Stores and retrieves qualified leads via API.
- **Gentle & Professional:** Persona designed to be empathetic and consultative.

## Project Structure

```
clara_ai_agent/
├── main.py                 # FastAPI backend application
├── requirements.txt        # Python dependencies
├── .env.example           # Environment variables template
├── README.md              # This file
└── venv/                  # Python virtual environment
```

## Prerequisites

- Python 3.8 or higher
- Twilio account with a phone number
- OpenAI API key (for GPT-4o)
- A public URL or ngrok tunnel to expose your local server

## Installation

### 1. Clone the Repository

```bash
cd /home/ubuntu/clara_ai_agent
```

### 2. Activate the Virtual Environment

```bash
source venv/bin/activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure Environment Variables

Copy the `.env.example` file to `.env` and fill in your credentials:

```bash
cp .env.example .env
```

Edit `.env` with your actual values:

```
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=your_auth_token_here
TWILIO_PHONE_NUMBER=+1234567890
OPENAI_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

## Running the Application

### Local Development

```bash
source venv/bin/activate
python main.py
```

The server will start on `http://localhost:8000`.

### Exposing to the Internet (Using ngrok)

To allow Twilio to send webhooks to your local server, you need to expose it:

```bash
# Install ngrok (if not already installed)
# Then run:
ngrok http 8000
```

This will give you a public URL like `https://xxxxxxxx.ngrok.io`.

### Configuring Twilio Webhooks

1. Go to your Twilio console: https://www.twilio.com/console
2. Navigate to **Phone Numbers** → **Active Numbers**
3. Select your phone number
4. Under **Voice & Fax**, set the **Webhook URL** to:
   ```
   https://your-ngrok-url.ngrok.io/incoming-call
   ```
5. Save the changes

## API Endpoints

### Health Check

```
GET /
```

Returns the status of the application.

### Incoming Call

```
POST /incoming-call
```

Twilio webhook endpoint that handles incoming calls. This is called automatically when someone calls your Twilio number.

### Process Response

```
POST /process-response/{call_sid}
```

Twilio webhook endpoint that processes the lead's response to each question.

### Get Leads

```
GET /leads
```

Returns all qualified leads and their responses.

**Example Response:**

```json
{
  "leads": {
    "CA1234567890abcdef": {
      "phone": "+1234567890",
      "question_index": 5,
      "answers": [
        {
          "question": "Are you the sole owner of the property?",
          "answer": "Yes, I am"
        },
        {
          "question": "What is the main reason for the sale?",
          "answer": "I'm relocating for work"
        }
      ],
      "started_at": "2025-12-18T21:50:00.000000"
    }
  },
  "total": 1
}
```

## The 5 Qualification Questions

Clara AI asks the following questions to qualify leads:

1. **Are you the sole owner of the property?**
2. **What is the main reason for the sale?**
3. **What is the minimum price you would accept for the house?**
4. **Does the house need any urgent repairs or have any known structural problems?**
5. **What is your ideal timeline for the sale?**

## Customization

### Changing the Questions

Edit the `QUALIFICATION_QUESTIONS` list in `main.py`:

```python
QUALIFICATION_QUESTIONS = [
    "Your custom question 1?",
    "Your custom question 2?",
    # ... etc
]
```

### Changing Clara's Persona

Edit the `SYSTEM_PROMPT` in `main.py` to customize Clara's tone and behavior.

### Changing the Voice

In the `response.say()` calls, you can change the voice from `"alice"` to other Twilio voices:
- `"alice"` (Female, American)
- `"man"` (Male, American)
- `"woman"` (Female, American)

## Production Deployment

For production, consider:

1. **Database:** Replace the in-memory `conversations` dictionary with a real database (PostgreSQL, MongoDB, etc.).
2. **Notifications:** Implement email/SMS notifications to alert your husband when a lead is qualified.
3. **Hosting:** Deploy to a cloud provider (AWS, Heroku, DigitalOcean, etc.).
4. **Security:** Use environment variables for all sensitive data.
5. **Logging:** Implement comprehensive logging for debugging and monitoring.

## Troubleshooting

### "Twilio credentials not found"

Make sure your `.env` file is properly configured with valid Twilio credentials.

### "OpenAI API key not found"

Verify that your OpenAI API key is correctly set in the `.env` file.

### "Webhook URL not responding"

Ensure that:
1. Your local server is running (`python main.py`)
2. ngrok is running and the URL is correct
3. The Twilio webhook URL is updated with the correct ngrok URL

## Support

For issues or questions, please refer to:
- Twilio Documentation: https://www.twilio.com/docs
- OpenAI Documentation: https://platform.openai.com/docs
- FastAPI Documentation: https://fastapi.tiangolo.com

## License

This project is created for educational and commercial use.

---

**Created by:** Manus AI
**Date:** December 18, 2025
**Version:** 1.0.0 (MVP)
